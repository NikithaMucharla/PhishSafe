
const question = [
    {
      question: "What is a common method used to deliver malware in phishing attacks?",
      answer: [
        {text : "Singing telegrams", correct:false},
        {text : "Physical letters", correct:false},
        {text : "Infected USB drives", correct:true},
        {text : "Handwritten notes ", correct:false},
      ]
    },
    {
      question: "How can you verify the legitimacy of an email sender?",
      answer: [
        {text : "By asking for their social media passwords", correct:false},
        {text : "By calling them and providing personal information", correct:false},
        {text : "By contacting the sender using information from the official website", correct:true},
        {text : "By replying to the email with your personal details ", correct:false},
      ]
    },
    {
      question: "What is the term for a type of phishing attack that relies on emotional manipulation?",
      answer: [
        {text : "Emotional fishing", correct:false},
        {text : "Psychological phishing", correct:true},
        {text : "Spear phishing", correct:false},
        {text : "Social engineering ", correct:false},
      ]
    },
    {
      question: "How do attackers use social media for phishing attacks?",
      answer: [
        {text : "By sending physical letters to victims", correct:false},
        {text : "By posting cat videos", correct:false},
        {text : "By impersonating friends or colleagues and sending malicious links", correct:true},
        {text : "By sharing inspirational quotes ", correct:false},
      ]
    },
    {
      question: "What is the term for a type of phishing attack that involves impersonating a legitimate organization?",
      answer: [
        {text : "Company phishing", correct:false},
        {text : "Clone phishing", correct:true},
        {text : "Genuine phishing", correct:false},
        {text : "Real phishing ", correct:false},
      ]
    },
    {
      question: "What should you do if you suspect you've received a phishing email?",
      answer: [
        {text : "Click on all the links to see where they lead", correct:false},
        {text : "Reply with personal information to confirm if it's legitimate", correct:false},
        {text : "Report the email to your organization's IT department or to the appropriate authorities", correct:true},
        {text : "Forward the email to all your contacts ", correct:false},
      ]
    }
  ];
  
  const questionElement = document.getElementById("question");
  const answerButton = document.getElementById("answer-buttons");
  const nextButton = document.getElementById("next-btn");
  
  let currentQuestionIndex = 0;
  let score = 0;
  
  function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
  }
  
  
  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
  
  
  function showQuestion(){
    resetState();
    let currentQuestion = question[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
    
    const shuffledAnswers = shuffle([...currentQuestion.answer]);
  
    shuffledAnswers.forEach(answer => {
      const button = document.createElement("button");
      button.innerHTML = answer.text;
      button.classList.add("btn");
      answerButton.appendChild(button);
      if(answer.correct){
        button.dataset.correct = answer.correct;
      }
      button.addEventListener("click", selectAnswer);
    });
  }
  
  function resetState(){
    nextButton.style.display = "none";
    while(answerButton.firstChild){
        answerButton.removeChild(answerButton.firstChild);
    }
  }
  
  function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButton.children).forEach(button => {
        if(button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
  }
  
  //function showScore(){
  //  resetState();
  //  questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  //  nextButton.innerHTML="Play Again";
   // nextButton.style.display="block";
  //}
  
  // function showScore(){
  //     resetState();
  //     questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  //     questionElement.style.textAlign= "center";
  
  //     const exitButton = document.createElement("button");
  //     exitButton.innerText = "Exit";
  //     exitButton.classList.add("btn");
  //     //exitButton.style.textAlign= "center";
  //     exitButton.style.background= "#001e4d";
  //     exitButton.style.color= "#fff";
  //     exitButton.style.width= "150px";
  //     exitButton.style.margin= "10px auto";
  //     exitButton.style.display="block";
  
  //     exitButton.addEventListener("click", () => {
  //         window.location.href = "quizzes.html"; // Replace with the URL of your exit page
  //     });
  //     nextButton.insertAdjacentElement("beforebegin", exitButton);
  
  //     nextButton.innerHTML = "Play Again";
  //     nextButton.style.display = "block";
  // }
  function showScore(){
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
    questionElement.style.textAlign = "center";
  
    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.display = "flex";
    buttonsContainer.style.justifyContent = "center";
  
    const exitButton = document.createElement("button");
    exitButton.innerText = "Exit";
    exitButton.style.textAlign= "center";
    exitButton.classList.add("btn");
    exitButton.style.background = "#001e4d";
    exitButton.style.color = "#fff";
    exitButton.style.width = "150px";
    exitButton.style.margin = "25px";
    exitButton.style.display = "block";
  
    exitButton.addEventListener("click", () => {
        window.location.href = "/quizzes"; 
    });
  
    const playAgainButton = document.createElement("button");
    playAgainButton.innerHTML = "Try Again";
    playAgainButton.style.textAlign= "center";
    playAgainButton.classList.add("btn");
    playAgainButton.style.background = "#001e4d";
    playAgainButton.style.color = "#fff";
    playAgainButton.style.width = "150px";
    playAgainButton.style.margin = "25px";
    playAgainButton.style.display = "block";
    playAgainButton.addEventListener("click", startQuiz);
  
    buttonsContainer.appendChild(exitButton);
    buttonsContainer.appendChild(playAgainButton);
  
    answerButton.appendChild(buttonsContainer);
  }
  
  
  
  
  function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < question.length){
        showQuestion();
    }else{
        showScore();
    }
  }
  
  nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < question.length){
        handleNextButton();
    }else{
        startQuiz();
    }
  });
  
  
  startQuiz();