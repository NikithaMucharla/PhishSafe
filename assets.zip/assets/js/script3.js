
const question = [
  {
    question: "what is pretexting in the context of phishing attacks?",
    answer: [
      {text : "A way to distract the victim with false pretences", correct:false},
      {text : "Creating a strong password", correct:false},
      {text : "Pretending to be someone else to manipulate the victim", correct:true},
      {text : "A form of encryption used by attackers ", correct:false},
    ]
  },
  {
    question: "What is the main reason why people fall for phishing attacks?",
    answer: [
      {text : "Lack of access to the internet", correct:false},
      {text : "Curiosity to see what the attacker wants", correct:false},
      {text : "Poor cybersecurity training and awareness", correct:true},
      {text : "Excessive use of antivirus software ", correct:false},
    ]
  },
  {
    question: "How do attackers create a sense of urgency in phishing emails?",
    answer: [
      {text : "By using excessive humour", correct:false},
      {text : "By promising financial rewards", correct:false},
      {text : "By threatening to reveal embarrassing information", correct:false},
      {text : "By claiming immediate action is required to avoid consequences ", correct:true},
    ]
  },
  {
    question: "What is the purpose of a phishing kit?",
    answer: [
      {text : "To help victims recover from phishing attacks", correct:false},
      {text : "To teach ethical hacking skills", correct:false},
      {text : "To provide tools and templates for creating phishing campaigns", correct:true},
      {text : "To offer free antivirus software ", correct:false},
    ]
  },
  {
    question: "Which of the following is an example of a phishing attack vector?",
    answer: [
      {text : "A mathematical equation", correct:false},
      {text : "A superhero comic book", correct:false},
      {text : "A compromised website", correct:true},
      {text : "A type of bird ", correct:false},
    ]
  },
  {
    question: "What is the purpose of email spoofing in a phishing attack?",
    answer: [
      {text : "To send friendly greetings", correct:false},
      {text : "To hide the sender's identity and impersonate a legitimate source", correct:true},
      {text : "To share interesting news articles", correct:false},
      {text : "To attach funny memes ", correct:false},
    ]
  }
];

const questionElement = document.getElementById("question");
const answerButton = document.getElementById("answer-buttons");
const nextButton = document.getElementById("next-btn");

let currentQuestionIndex = 0;
let score = 0;

function startQuiz(){
  currentQuestionIndex = 0;
  score = 0;
  nextButton.innerHTML = "Next";
  showQuestion();
}


function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}


function showQuestion(){
  resetState();
  let currentQuestion = question[currentQuestionIndex];
  let questionNo = currentQuestionIndex + 1;
  questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
  
  const shuffledAnswers = shuffle([...currentQuestion.answer]);

  shuffledAnswers.forEach(answer => {
    const button = document.createElement("button");
    button.innerHTML = answer.text;
    button.classList.add("btn");
    answerButton.appendChild(button);
    if(answer.correct){
      button.dataset.correct = answer.correct;
    }
    button.addEventListener("click", selectAnswer);
  });
}

function resetState(){
  nextButton.style.display = "none";
  while(answerButton.firstChild){
      answerButton.removeChild(answerButton.firstChild);
  }
}

function selectAnswer(e) {
  const selectedBtn = e.target;
  const isCorrect = selectedBtn.dataset.correct === "true";
  
  if(isCorrect){
      selectedBtn.classList.add("correct");
      score++;
  }else{
      selectedBtn.classList.add("incorrect");
  }
  Array.from(answerButton.children).forEach(button => {
      if(button.dataset.correct === "true") {
          button.classList.add("correct");
      }
      button.disabled = true;
  });
  nextButton.style.display = "block";
}

//function showScore(){
//  resetState();
//  questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
//  nextButton.innerHTML="Play Again";
 // nextButton.style.display="block";
//}

// function showScore(){
//     resetState();
//     questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
//     questionElement.style.textAlign= "center";

//     const exitButton = document.createElement("button");
//     exitButton.innerText = "Exit";
//     exitButton.classList.add("btn");
//     //exitButton.style.textAlign= "center";
//     exitButton.style.background= "#001e4d";
//     exitButton.style.color= "#fff";
//     exitButton.style.width= "150px";
//     exitButton.style.margin= "10px auto";
//     exitButton.style.display="block";

//     exitButton.addEventListener("click", () => {
//         window.location.href = "quizzes.html"; // Replace with the URL of your exit page
//     });
//     nextButton.insertAdjacentElement("beforebegin", exitButton);

//     nextButton.innerHTML = "Play Again";
//     nextButton.style.display = "block";
// }
function showScore(){
  resetState();
  questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  questionElement.style.textAlign = "center";

  const buttonsContainer = document.createElement("div");
  buttonsContainer.style.display = "flex";
  buttonsContainer.style.justifyContent = "center";

  const exitButton = document.createElement("button");
  exitButton.innerText = "Exit";
  exitButton.style.textAlign= "center";
  exitButton.classList.add("btn");
  exitButton.style.background = "#001e4d";
  exitButton.style.color = "#fff";
  exitButton.style.width = "150px";
  exitButton.style.margin = "25px";
  exitButton.style.display = "block";

  exitButton.addEventListener("click", () => {
      window.location.href = "/quizzes"; 
  });

  const playAgainButton = document.createElement("button");
  playAgainButton.innerHTML = "Try Again";
  playAgainButton.style.textAlign= "center";
  playAgainButton.classList.add("btn");
  playAgainButton.style.background = "#001e4d";
  playAgainButton.style.color = "#fff";
  playAgainButton.style.width = "150px";
  playAgainButton.style.margin = "25px";
  playAgainButton.style.display = "block";
  playAgainButton.addEventListener("click", startQuiz);

  buttonsContainer.appendChild(exitButton);
  buttonsContainer.appendChild(playAgainButton);

  answerButton.appendChild(buttonsContainer);
}




function handleNextButton(){
  currentQuestionIndex++;
  if(currentQuestionIndex < question.length){
      showQuestion();
  }else{
      showScore();
  }
}

nextButton.addEventListener("click", ()=>{
  if(currentQuestionIndex < question.length){
      handleNextButton();
  }else{
      startQuiz();
  }
});


startQuiz();