
const question = [
    {
      question: "Which one of these statements is correct?",
      answer: [
        {text : "If you get an email that looks like it’s from someone you know, you can click on any links as long as you have a spam blocker and anti-virus protection", correct:false},
        {text : "You can trust an email really comes from a client if it uses the client’s logo and contains at least one fact about the client that you know to be true.", correct:false},
        {text : "If you get a message from a colleague who needs your network password, you should never give it out unless the colleague says it’s an emergency.", correct:false},
        {text : "If you get an email from Human Resources asking you to provide personal information right away, you should check it out first to make sure they are who they say are.", correct:true},
      ]
    },
    {
      question: "What are the most popular signs of a phishing scam?",
      answer: [
        {text : "The email comes with a disclaimer/alert notifying the user that it is spam.", correct:false},
        {text : "The email is empty and contains nothing in the subject or body.", correct:false},
        {text : "An authentic sender sending regular subscribed updates.", correct:false},
        {text : "Inconsistency in the sender’s email ID and how the recipient is addressed.", correct:true},
      ]
    },
    {
      question: "How many phishing emails are sent every day globally?",
      answer: [
        {text : "Billions", correct:true},
        {text : "Millions", correct:false},
        {text : "Thousands", correct:false},
        {text : "Hundreds", correct:false},
      ]
    },
    {
      question: "What happens if you click on a phishing email link or attachment?",
      answer: [
        {text : "Browser/app is closed without any prompt.", correct:false},
        {text : "You are redirected to a website that asks you to enter sensitive information or directs you to download an attachment.", correct:true},
        {text : "You get an error page on the screen.", correct:false},
        {text : "None of the above", correct:false},
      ]
    },
    {
      question: "Why do I need to watch out for phishing emails?",
      answer: [
        {text : "For personal safety and security.", correct:false},
        {text : "To protect your identity and sensitive information.", correct:false},
        {text : "To prevent being duped and falling for scams.", correct:false},
        {text : "All of the above.", correct:true},
      ]
    },
    {
      question: "What should you do if you’re unsure whether an email is real?",
      answer: [
        {text : "Ignore the source and proceed anyway.", correct:false},
        {text : "Click on the link/download the attachment to find out.", correct:false},
        {text : "Learn and educate yourself with security awareness training.", correct:true},
        {text : "Forward the link to friends/colleagues and ask them if it’s trustworthy.", correct:false},
      ]
    }
  ];

  const questionElement = document.getElementById("question");
  const answerButton = document.getElementById("answer-buttons");
  const nextButton = document.getElementById("next-btn");

  let currentQuestionIndex = 0;
  let score = 0;

  function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
  }


  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}


  function showQuestion(){
    resetState();
    let currentQuestion = question[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
    
    const shuffledAnswers = shuffle([...currentQuestion.answer]);

    shuffledAnswers.forEach(answer => {
      const button = document.createElement("button");
      button.innerHTML = answer.text;
      button.classList.add("btn");
      answerButton.appendChild(button);
      if(answer.correct){
        button.dataset.correct = answer.correct;
      }
      button.addEventListener("click", selectAnswer);
    });
  }

  function resetState(){
    nextButton.style.display = "none";
    while(answerButton.firstChild){
        answerButton.removeChild(answerButton.firstChild);
    }
  }

function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButton.children).forEach(button => {
        if(button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
}

//function showScore(){
  //  resetState();
  //  questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  //  nextButton.innerHTML="Play Again";
   // nextButton.style.display="block";
//}

// function showScore(){
//     resetState();
//     questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
//     questionElement.style.textAlign= "center";

//     const exitButton = document.createElement("button");
//     exitButton.innerText = "Exit";
//     exitButton.classList.add("btn");
//     //exitButton.style.textAlign= "center";
//     exitButton.style.background= "#001e4d";
//     exitButton.style.color= "#fff";
//     exitButton.style.width= "150px";
//     exitButton.style.margin= "10px auto";
//     exitButton.style.display="block";

//     exitButton.addEventListener("click", () => {
//         window.location.href = "quizzes.html"; // Replace with the URL of your exit page
//     });
//     nextButton.insertAdjacentElement("beforebegin", exitButton);

//     nextButton.innerHTML = "Play Again";
//     nextButton.style.display = "block";
// }
function showScore(){
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
    questionElement.style.textAlign = "center";

    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.display = "flex";
    buttonsContainer.style.justifyContent = "center";

    const exitButton = document.createElement("button");
    exitButton.innerText = "Exit";
    exitButton.style.textAlign= "center";
    exitButton.classList.add("btn");
    exitButton.style.background = "#001e4d";
    exitButton.style.color = "#fff";
    exitButton.style.width = "150px";
    exitButton.style.margin = "25px";
    exitButton.style.display = "block";

    exitButton.addEventListener("click", () => {
        window.location.href = "/quizzes"; 
    });

    const playAgainButton = document.createElement("button");
    playAgainButton.innerHTML = "Try Again";
    playAgainButton.style.textAlign= "center";
    playAgainButton.classList.add("btn");
    playAgainButton.style.background = "#001e4d";
    playAgainButton.style.color = "#fff";
    playAgainButton.style.width = "150px";
    playAgainButton.style.margin = "25px";
    playAgainButton.style.display = "block";
    playAgainButton.addEventListener("click", startQuiz);

    buttonsContainer.appendChild(exitButton);
    buttonsContainer.appendChild(playAgainButton);

    answerButton.appendChild(buttonsContainer);
}




function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < question.length){
        showQuestion();
    }else{
        showScore();
    }
}

nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < question.length){
        handleNextButton();
    }else{
        startQuiz();
    }
});


startQuiz();