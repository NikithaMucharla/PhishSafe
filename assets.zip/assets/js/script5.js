
const question = [
    {
      question: "What is vishing?",
      answer: [
        {text : "A type of phishing attack involving voicemail", correct:true},
        {text : "A phishing attack that uses only video content", correct:false},
        {text : "A type of fishing done at sea", correct:false},
        {text : "A form of virtual reality phishing ", correct:false},
      ]
    },
    {
      question: "What is the role of a baiting attack in phishing?",
      answer: [
        {text : "To catch fish in the sea", correct:false},
        {text : "To offer something enticing in exchange for sensitive information", correct:true},
        {text : "To teach fishing techniques", correct:false},
        {text : "To create a noisy distraction ", correct:false},
      ]
    },
    {
      question: "What is the purpose of a phishing simulation in cybersecurity training?",
      answer: [
        {text : "To trick employees into revealing sensitive information", correct:false},
        {text : "To demonstrate the process of fishing", correct:false},
        {text : "To increase awareness and teach employees to recognize phishing attempts", correct:true},
        {text : "To showcase the benefits of using phishing as a security technique ", correct:false},
      ]
    },
    {
      question: "What is a keylogger in the context of phishing attacks?",
      answer: [
        {text : "A tool used to unlock doors", correct:false},
        {text : "A hardware device used for fishing", correct:false},
        {text : "A software program that captures keystrokes", correct:true},
        {text : "A type of encryption used by attackers ", correct:false},
      ]
    },
    {
      question: "What is the term for a phishing attack that targets a specific organization?",
      answer: [
        {text : "Universal phishing", correct:false},
        {text : "Organizational phishing", correct:true},
        {text : "Company-wide phishing", correct:false},
        {text : "Whale phishing ", correct:false},
      ]
    },
    {
      question: "What is the main goal of pretexting in a phishing attack?",
      answer: [
        {text : "To create a fictional story", correct:false},
        {text : "To entertain the victim", correct:false},
        {text : "To manipulate the victim into revealing information", correct:true},
        {text : "To provide evidence for a legal case ", correct:false},
      ]
    }
  ];
  
  const questionElement = document.getElementById("question");
  const answerButton = document.getElementById("answer-buttons");
  const nextButton = document.getElementById("next-btn");
  
  let currentQuestionIndex = 0;
  let score = 0;
  
  function startQuiz(){
    currentQuestionIndex = 0;
    score = 0;
    nextButton.innerHTML = "Next";
    showQuestion();
  }
  
  
  function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }
  
  
  function showQuestion(){
    resetState();
    let currentQuestion = question[currentQuestionIndex];
    let questionNo = currentQuestionIndex + 1;
    questionElement.innerHTML = questionNo + ". " + currentQuestion.question;
    
    const shuffledAnswers = shuffle([...currentQuestion.answer]);
  
    shuffledAnswers.forEach(answer => {
      const button = document.createElement("button");
      button.innerHTML = answer.text;
      button.classList.add("btn");
      answerButton.appendChild(button);
      if(answer.correct){
        button.dataset.correct = answer.correct;
      }
      button.addEventListener("click", selectAnswer);
    });
  }
  
  function resetState(){
    nextButton.style.display = "none";
    while(answerButton.firstChild){
        answerButton.removeChild(answerButton.firstChild);
    }
  }
  
  function selectAnswer(e) {
    const selectedBtn = e.target;
    const isCorrect = selectedBtn.dataset.correct === "true";
    
    if(isCorrect){
        selectedBtn.classList.add("correct");
        score++;
    }else{
        selectedBtn.classList.add("incorrect");
    }
    Array.from(answerButton.children).forEach(button => {
        if(button.dataset.correct === "true") {
            button.classList.add("correct");
        }
        button.disabled = true;
    });
    nextButton.style.display = "block";
  }
  
  //function showScore(){
  //  resetState();
  //  questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  //  nextButton.innerHTML="Play Again";
   // nextButton.style.display="block";
  //}
  
  // function showScore(){
  //     resetState();
  //     questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
  //     questionElement.style.textAlign= "center";
  
  //     const exitButton = document.createElement("button");
  //     exitButton.innerText = "Exit";
  //     exitButton.classList.add("btn");
  //     //exitButton.style.textAlign= "center";
  //     exitButton.style.background= "#001e4d";
  //     exitButton.style.color= "#fff";
  //     exitButton.style.width= "150px";
  //     exitButton.style.margin= "10px auto";
  //     exitButton.style.display="block";
  
  //     exitButton.addEventListener("click", () => {
  //         window.location.href = "quizzes.html"; // Replace with the URL of your exit page
  //     });
  //     nextButton.insertAdjacentElement("beforebegin", exitButton);
  
  //     nextButton.innerHTML = "Play Again";
  //     nextButton.style.display = "block";
  // }
  function showScore(){
    resetState();
    questionElement.innerHTML = `You scored ${score} out of ${question.length}!`;
    questionElement.style.textAlign = "center";
  
    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.display = "flex";
    buttonsContainer.style.justifyContent = "center";
  
    const exitButton = document.createElement("button");
    exitButton.innerText = "Exit";
    exitButton.style.textAlign= "center";
    exitButton.classList.add("btn");
    exitButton.style.background = "#001e4d";
    exitButton.style.color = "#fff";
    exitButton.style.width = "150px";
    exitButton.style.margin = "25px";
    exitButton.style.display = "block";
  
    exitButton.addEventListener("click", () => {
        window.location.href = "/quizzes"; 
    });
  
    const playAgainButton = document.createElement("button");
    playAgainButton.innerHTML = "Try Again";
    playAgainButton.style.textAlign= "center";
    playAgainButton.classList.add("btn");
    playAgainButton.style.background = "#001e4d";
    playAgainButton.style.color = "#fff";
    playAgainButton.style.width = "150px";
    playAgainButton.style.margin = "25px";
    playAgainButton.style.display = "block";
    playAgainButton.addEventListener("click", startQuiz);
  
    buttonsContainer.appendChild(exitButton);
    buttonsContainer.appendChild(playAgainButton);
  
    answerButton.appendChild(buttonsContainer);
  }
  
  
  
  
  function handleNextButton(){
    currentQuestionIndex++;
    if(currentQuestionIndex < question.length){
        showQuestion();
    }else{
        showScore();
    }
  }
  
  nextButton.addEventListener("click", ()=>{
    if(currentQuestionIndex < question.length){
        handleNextButton();
    }else{
        startQuiz();
    }
  });
  
  
  startQuiz();